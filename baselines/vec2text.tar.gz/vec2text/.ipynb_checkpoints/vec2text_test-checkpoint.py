import argparse
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer
from tqdm import tqdm
import numpy as np
import logging
import random 
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vec2text

import time 
import math
from datasets import load_dataset

import warnings
from transformers.utils import logging
warnings.filterwarnings("ignore")
logging.set_verbosity_error()  # Suppresses HuggingFace warnings
from sentence_transformers import SentenceTransformer, util

def get_gpu_device():
    n_gpus = torch.cuda.device_count()
    print(f"Total GPUS: {n_gpus}")
    if n_gpus <= 0:
        print("Decide to use CPU")
        return torch.device("cpu")
    idx = -1
    temfree = 0
    for i in range(n_gpus):
        cdevice = torch.device(f"cuda:{i}")
        free, total = torch.cuda.mem_get_info(cdevice)
        free = free * 1.0 / 1024 / 1024 / 1024
        total = total * 1.0 / 1024 / 1024 / 1024
        allocated = torch.torch.cuda.memory_allocated(cdevice)
        allocated = allocated * 1.0 / 1024 / 1024 / 1024
        if free > temfree:
            temfree = free 
            idx = i 
        print(f"For GPU {i}, MEMORY Info Free {free:.3f}, Total {total:.3f}, Allocated {allocated:.3f}")
    
    print(f"Decide to use GPU {idx}")
    return torch.device(f"cuda:{idx}")
    
def reconstructRA(reconststr, gtstr, tokenizer):
    token_ids_yhat = tokenizer.encode(reconststr)
    token_ids_y = tokenizer.encode(gtstr)
    
    raacc = []
    ylst = torch.tensor(token_ids_y).squeeze()
    yhatlst = torch.tensor(token_ids_yhat).squeeze()
    for i in range(min(len(yhatlst), len(ylst))): 
        if yhatlst[i].item() == ylst[i].item(): 
            raacc.append(1.0)
        else:
            raacc.append(0.0)
    return raacc

def reconstructCSS(recststr, gtstr, semanticLLM):
    embeddings = semanticLLM.encode([gtstr, recststr])
    # Compute cosine similarity
    cosine_similarity = util.pytorch_cos_sim(embeddings[0], embeddings[1]).item()
    return cosine_similarity

def readTestPrompts(datasetdir, samples=1000):
    # load dataset
    if datasetdir == "SQuAD2.0":
        traindatapath = f"..{os.sep}datasets{os.sep}{datasetdir}{os.sep}SQuAD2.0-train-QandA-Pairs.lst"
    elif datasetdir == "Wikitext2":
        traindatapath = f"..{os.sep}datasets{os.sep}{datasetdir}{os.sep}Wikitext2-Merge-Articles-19771.lst"  # Sorted, from short to long
    elif datasetdir == "MidjourneyPrompts":
        traindatapath = f"..{os.sep}datasets{os.sep}{datasetdir}{os.sep}MidjourneyPrompts-Prompt-Sorted-123642.lst"  # Sorted, from short to long
    elif datasetdir == "PrivatePrompts":
        traindatapath = f"..{os.sep}datasets{os.sep}{datasetdir}{os.sep}ProvatePrompts-Length-Sorted-251270.lst"  # Sorted, from short to long    
    else: 
        raise ValueError(f'Unsupported datasetdir {datasetdir}')
    print(f"Load dataset from {traindatapath}")

    testprompts = torch.load(traindatapath, weights_only=False)
    if samples <= 0:
        return testprompts
    else:
        return testprompts[:samples]
        
def loadTokenizer(modelname):   

    print(f"Loading tokenizer for {modelname}")
    if "gpt" in modelname.lower():        
        from transformers import GPT2Tokenizer
        tokenizer = GPT2Tokenizer.from_pretrained("gpt2-large", padding_side='left', clean_up_tokenization_spaces=True)
        tokenizer.pad_token = tokenizer.eos_token
    elif "llama" in modelname.lower():   
        tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B", padding_side='left', clean_up_tokenization_spaces=True)
        tokenizer.pad_token = tokenizer.eos_token
    elif "phi" in modelname.lower():        
        tokenizer = AutoTokenizer.from_pretrained("microsoft/Phi-3.5-mini-instruct", trust_remote_code=True, padding_side='left', clean_up_tokenization_spaces=True)
        tokenizer.pad_token = tokenizer.eos_token
    elif "bert" in modelname.lower():          
        from transformers import BertTokenizer
        tokenizer = BertTokenizer.from_pretrained("bert-large-cased", trust_remote_code=True, padding_side='left', clean_up_tokenization_spaces=True)
        # tokenizer.pad_token = tokenizer.eos_token
    else:
        raise ValueError(f'Unsupported model name {modelname}') 
                
    return tokenizer  
    
def main():
    parser = argparse.ArgumentParser(description="Example script for parameter parsing.")
    parser.add_argument("--embedder_model_name", type=str, required=True,
                        help="Name of the embedder model.")
    parser.add_argument("--embeddings_from_layer_n", type=int, required=True,
                        help="Layer number to extract embeddings from.")

    args = parser.parse_args()

    print(f"Embedder Model Name: {args.embedder_model_name}")
    print(f"Embeddings from Layer: {args.embeddings_from_layer_n}")

    modelname = args.embedder_model_name
    layer = args.embeddings_from_layer_n
    tokenizer = loadTokenizer(modelname)
    device = get_gpu_device()
    
    print("\nLoading semantic evaluation LLM: sentence-bert-base")
    semanticLLM = SentenceTransformer('efederici/sentence-bert-base').to(device)
    

    inversion_model = vec2text.models.InversionModel.from_pretrained(f"./vec2text_cache/saves/{modelname}_layer_{layer}").to(device)
    corrector_model = vec2text.models.CorrectorEncoderModel.from_pretrained(f"./vec2text_cache/saves/{modelname}_layer_{layer}_corrector").to(device)
    corrector = vec2text.load_corrector(inversion_model, corrector_model)
    print("Loading corrector finished!")
    ####################### Compute Reconstruction Accuracy #######################
    print("\n----------------- Reconstruction Accuracy -----------------")
    
    for datasetdir in ("Wikitext2", "SQuAD2.0", "MidjourneyPrompts"):
        testprompts = readTestPrompts(datasetdir, samples=10)
        if datasetdir == "SQuAD2.0":
            testprompts = [testprompts[i][0] for i in range(len(testprompts))]  # for SQuAD2.0
            
        RAlst = []
        CSSlst = []
        with torch.no_grad():
            recststrs = vec2text.invert_strings(testprompts, corrector=corrector)
        
        for idx in range(len(testprompts)):
            recststr = recststrs[idx]
            gtstr = testprompts[idx]
            RAlst.extend(reconstructRA(recststr, gtstr, tokenizer))
            CSSlst.append(reconstructCSS(recststr, gtstr, semanticLLM))
                
        print(f"For test dataset {datasetdir}:")
    
        print(f"\tReconstructed accuracy via vec2text is:")
        print(f"\tToken-Level Acc: {torch.tensor(RAlst).mean().item():.4f}, Semantic-level ACC: {torch.tensor(CSSlst).mean().item():.4f}\n\n")

if __name__ == "__main__":
    main()
