import transformers
from vec2text.experiments import experiment_from_args
from vec2text.run_args import DataArguments, ModelArguments, TrainingArguments
import logging
import os
import torch
import torch.distributed as dist
os.environ['MASTER_ADDR'] = 'localhost'
os.environ['MASTER_PORT'] = '29500'

def initlogging(logfilename):
    def getTimeStamp():
        from datetime import datetime
        return datetime.now().strftime("_%Y%m%d_%H_%M_%S")
        
    import logging
    import os
    
    # 1. Extract directory path, egg. "./log/test/mylog" -> "./log/test/"
    logdir = os.path.dirname(logfilename)
    # 2. Create the directory if it doesn't exist
    os.makedirs(logdir, exist_ok=True)
    
    logfile = f"{logfilename}_{getTimeStamp()}.log"
    # debug, info, warning, error, critical
    # set up logging to file
    logging.shutdown()
    
    logger = logging.getLogger()
    logger.handlers = []
    
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
                        filename=logfile,
                        filemode='w')
    
    # create console handler
    ch = logging.StreamHandler()
    # Sets the threshold for this handler. 
    # Logging messages which are less severe than this level will be ignored, i.e.,
    # logging messages with < critical levels will not be printed on screen
    # E.g., 
    # logging.info("This should be only in file") 
    # logging.critical("This shoud be in both file and console")
    
    ch.setLevel(logging.CRITICAL)
    # add formatter to ch
    ch.setFormatter(logging.Formatter('%(message)s'))
    logging.getLogger().addHandler(ch)  
    return logfile

def main():
    parser = transformers.HfArgumentParser(
        (ModelArguments, DataArguments, TrainingArguments)
    )
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    initlogging(f"./logs/mylog_{model_args.embedder_model_name}_layer{model_args.embeddings_from_layer_n}")
    # Define VEC2TEXT_CACHE using embedder_model_name and embeddings_from_layer_n
    assert model_args.embedder_model_name is not None
    assert model_args.embeddings_from_layer_n is not None
    cache_path = f"/l/users/xinjian.luo/vec2text_cache/.cache/inversion_{model_args.embedder_model_name}_layer{model_args.embeddings_from_layer_n}"
    os.environ["VEC2TEXT_CACHE"] = cache_path
    logger = logging.getLogger(__name__)
    logger.critical(f"Set environment variable VEC2TEXT_CACHE={cache_path}")  
    # Create the directory if it doesn't exist
    os.makedirs(cache_path, exist_ok=True)
    
    experiment = experiment_from_args(model_args, data_args, training_args)
    experiment.run()


if __name__ == "__main__":
    main()
