import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer
from tqdm import tqdm
import numpy as np
import logging
import random 
import os 
import time 
import vec2text
import math

inversion_model = vec2text.models.InversionModel.from_pretrained("saves/gpt")
corrector_model = vec2text.models.CorrectorEncoderModel.from_pretrained("saves/gpt-corrector")

corrector = vec2text.load_corrector(inversion_model, corrector_model)



origstr = [
        "Jack Morris is a PhD student at Cornell Tech in New York City",
        "It was the best of times, it was the worst of times, it was the age of wisdom, it was the age of foolishness, it was the epoch of belief, it was the epoch of incredulity"
    ]
print(f"Original strings is:\n{origstr}")
reconst = vec2text.invert_strings(origstr, corrector=corrector)
print(f"Reconstructed strings is:\n{reconst}")



